﻿
using Microsoft.EntityFrameworkCore;
using System.Text;
using UniversityApp.Core;
using System.Linq;

Console.OutputEncoding = Encoding.Unicode;

using (var ctx = new UniversityContext())
{
    foreach(var t in ctx.Teachers.Include(x=> x.Courses).ToList())
    {
        Console.WriteLine(t.Title);
        foreach(var c in t.Courses)
        {
            Console.WriteLine($"\t{c.Title}");
        }
    }
}
