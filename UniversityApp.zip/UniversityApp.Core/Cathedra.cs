﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UniversityApp.Core
{
    public class Cathedra
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }
        public string? Title { get; set; }
        public Faculty? Faculty { get; set; }
        public virtual ICollection<Group> Groups { get; set; } = new List<Group>();
        public virtual ICollection<Teacher> Teacher { get; set; } = new List<Teacher>();

        public override string ToString()
        {
            return Title;
        }
    }
}
