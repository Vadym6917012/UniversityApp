﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UniversityApp.Core
{
    public class UniversityContext : DbContext
    {
        public UniversityContext()
        {
            //Database.EnsureDeleted();
        }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            builder.Entity<Faculty>().HasData(
                new Faculty { Id = 1, Title = "Економічний" },
                new Faculty { Id = 2, Title = "РГМ" }
                );

            builder.Entity<Teacher>()
                .HasMany(x => x.Courses)
                .WithMany(x => x.Teachers);
        }

        protected override void OnConfiguring(DbContextOptionsBuilder options)
        {
            options.UseSqlServer(@"Server=.\;Database=UniversityDb;Trusted_connection=true");
        }

        public DbSet<Cathedra>? Cathedras { get; set; }
        public DbSet<Faculty>? Faculties { get; set; }
        public DbSet<Group>? Groups { get; set; }
        public DbSet<Student> Students { get; set; }
        public DbSet<Teacher> Teachers { get; set; }
        public DbSet<Course> Courses { get; set; }
    }
}
