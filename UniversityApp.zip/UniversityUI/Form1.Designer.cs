﻿namespace UniversityUI
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonAddTeacher = new System.Windows.Forms.Button();
            this.comboBoxCathedras = new System.Windows.Forms.ComboBox();
            this.textBoxteacherName = new System.Windows.Forms.TextBox();
            this.listBoxTeachers = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.comboBoxCourses = new System.Windows.Forms.ComboBox();
            this.buttonAddToCourse = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // buttonAddTeacher
            // 
            this.buttonAddTeacher.Location = new System.Drawing.Point(25, 131);
            this.buttonAddTeacher.Name = "buttonAddTeacher";
            this.buttonAddTeacher.Size = new System.Drawing.Size(75, 23);
            this.buttonAddTeacher.TabIndex = 0;
            this.buttonAddTeacher.Text = "Add Teacher";
            this.buttonAddTeacher.UseVisualStyleBackColor = true;
            this.buttonAddTeacher.Click += new System.EventHandler(this.buttonAddTeacher_Click);
            // 
            // comboBoxCathedras
            // 
            this.comboBoxCathedras.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxCathedras.FormattingEnabled = true;
            this.comboBoxCathedras.Location = new System.Drawing.Point(25, 24);
            this.comboBoxCathedras.Name = "comboBoxCathedras";
            this.comboBoxCathedras.Size = new System.Drawing.Size(165, 23);
            this.comboBoxCathedras.TabIndex = 1;
            // 
            // textBoxteacherName
            // 
            this.textBoxteacherName.Location = new System.Drawing.Point(25, 92);
            this.textBoxteacherName.Name = "textBoxteacherName";
            this.textBoxteacherName.Size = new System.Drawing.Size(165, 23);
            this.textBoxteacherName.TabIndex = 2;
            // 
            // listBoxTeachers
            // 
            this.listBoxTeachers.FormattingEnabled = true;
            this.listBoxTeachers.ItemHeight = 15;
            this.listBoxTeachers.Location = new System.Drawing.Point(221, 24);
            this.listBoxTeachers.Name = "listBoxTeachers";
            this.listBoxTeachers.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.listBoxTeachers.Size = new System.Drawing.Size(168, 334);
            this.listBoxTeachers.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(27, 72);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(79, 15);
            this.label1.TabIndex = 4;
            this.label1.Text = "TeacherName";
            // 
            // comboBoxCourses
            // 
            this.comboBoxCourses.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxCourses.FormattingEnabled = true;
            this.comboBoxCourses.Location = new System.Drawing.Point(409, 24);
            this.comboBoxCourses.Name = "comboBoxCourses";
            this.comboBoxCourses.Size = new System.Drawing.Size(165, 23);
            this.comboBoxCourses.TabIndex = 5;
            // 
            // buttonAddToCourse
            // 
            this.buttonAddToCourse.Location = new System.Drawing.Point(409, 72);
            this.buttonAddToCourse.Name = "buttonAddToCourse";
            this.buttonAddToCourse.Size = new System.Drawing.Size(165, 23);
            this.buttonAddToCourse.TabIndex = 6;
            this.buttonAddToCourse.Text = "Add Teachers To Course";
            this.buttonAddToCourse.UseVisualStyleBackColor = true;
            this.buttonAddToCourse.Click += new System.EventHandler(this.buttonAddToCourse_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(708, 407);
            this.Controls.Add(this.buttonAddToCourse);
            this.Controls.Add(this.comboBoxCourses);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.listBoxTeachers);
            this.Controls.Add(this.textBoxteacherName);
            this.Controls.Add(this.comboBoxCathedras);
            this.Controls.Add(this.buttonAddTeacher);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Button buttonAddTeacher;
        private ComboBox comboBoxCathedras;
        private TextBox textBoxteacherName;
        private ListBox listBoxTeachers;
        private Label label1;
        private ComboBox comboBoxCourses;
        private Button buttonAddToCourse;
    }
}