using Microsoft.EntityFrameworkCore;
using UniversityApp.Core;

namespace UniversityUI
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            UpdateCathedras();
            UpdateTeachers();
            UpdateCourses();
        }

        private void UpdateCourses()
        {
            using (var ctx = new UniversityContext())
            {
                comboBoxCourses.Items.Clear();
                comboBoxCourses.Items.AddRange(ctx.Courses.ToArray());
                comboBoxCourses.SelectedIndex = 0;
            }
        }

        private void UpdateCathedras()
        {
            using (var ctx = new UniversityContext())
            {
                comboBoxCathedras.Items.Clear();
                comboBoxCathedras.Items.AddRange(ctx.Cathedras.ToArray());
                comboBoxCathedras.SelectedIndex = 0;
            }
        }

        private void UpdateTeachers()
        {
            using (var ctx = new UniversityContext())
            {
                listBoxTeachers.Items.Clear();
                listBoxTeachers.Items.AddRange(ctx.Teachers.ToArray());
            }
        }

        private void buttonAddTeacher_Click(object sender, EventArgs e)
        {
            //check!!!

            using (var ctx = new UniversityContext())
            {
                var cathedraObj = comboBoxCathedras.SelectedItem as Cathedra;

                var teacher = new Teacher()
                {
                    Title = textBoxteacherName.Text,
                    Cathedra = ctx.Cathedras.Find(cathedraObj.Id)
                };

                ctx.Teachers.Add(teacher);
                ctx.SaveChanges();
            }

            UpdateTeachers();
        }

        private void buttonAddToCourse_Click(object sender, EventArgs e)
        {
            //check!!!!

            using (var ctx = new UniversityContext())
            {
                var selectedCourse = comboBoxCourses.SelectedItem as Course;

                var courseInDb = ctx.Courses.Include(x=> x.Teachers).First(x=> x.Id == selectedCourse.Id);
                foreach(var teacher in listBoxTeachers.SelectedItems)
                {
                    var t = teacher as Teacher;
                    
                    if (courseInDb.Teachers.Any(x => x.Id == t.Id))
                    {
                        MessageBox.Show($"Teacher {t.Title} already added to course {courseInDb.Title}");
                    } 
                    else
                    {
                        courseInDb.Teachers.Add(ctx.Teachers.Find(t.Id));
                    }
                    
                }

                ctx.SaveChanges();
            }
        }
    }


}